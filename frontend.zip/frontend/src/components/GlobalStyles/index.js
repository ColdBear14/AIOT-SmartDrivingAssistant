import  './GlobalStyles.css'
function GlobalStyles({ children }) {
  return (
    children
  )
}

export default GlobalStyles